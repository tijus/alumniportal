<?php

namespace frontend\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use frontend\models\Discussion;

/**
 * DiscussionSearch represents the model behind the search form about `frontend\models\Discussion`.
 */
class DiscussionSearch extends Discussion
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['discussion_id'], 'integer'],
            [['discussion_name', 'discussion_description'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Discussion::find();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        $query->andFilterWhere([
            'discussion_id' => $this->discussion_id,
        ]);

        $query->andFilterWhere(['like', 'discussion_name', $this->discussion_name])
            ->andFilterWhere(['like', 'discussion_description', $this->discussion_description]);

        return $dataProvider;
    }
}
